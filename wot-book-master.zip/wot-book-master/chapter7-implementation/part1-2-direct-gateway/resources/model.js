var resources = require('./resources.json');
module.exports = resources;

