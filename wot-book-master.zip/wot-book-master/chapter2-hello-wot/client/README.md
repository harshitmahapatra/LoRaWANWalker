wot-book: chapter 2: client examples
====================================

http-server --cors -c-1