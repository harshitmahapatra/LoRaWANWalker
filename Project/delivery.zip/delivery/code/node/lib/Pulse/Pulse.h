int GetAvgHR(int8_t);
int GetAvgHRMain(int8_t);