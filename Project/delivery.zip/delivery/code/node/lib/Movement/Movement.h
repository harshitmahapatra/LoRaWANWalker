#include <Arduino.h>
#include <MPU9250.h>

bool IsMoving(MPU9250 IMU);